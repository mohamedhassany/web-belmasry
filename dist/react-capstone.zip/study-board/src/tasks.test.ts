import { test, expect } from 'vitest';
import { parseTasks, tasksReducer, validateTitle } from './tasks';
import type { Task } from './types';
test('title validation covers blank, short, boundary and excessive input', () => {
  expect(validateTitle('   ')).not.toBe('');
  expect(validateTitle('ab')).not.toBe('');
  expect(validateTitle('abc')).toBe('');
  expect(validateTitle('a'.repeat(80))).toBe('');
  expect(validateTitle('a'.repeat(81))).not.toBe('');
});
test('reducer creates a new task list and never mutates existing task objects', () => {
  const before: Task[] = [{ id: 'a', title: 'React', done: false }];
  Object.freeze(before[0]); Object.freeze(before);
  const after = tasksReducer(before, { type: 'toggled', id: 'a' });
  expect(after[0].done).toBe(true); expect(before[0].done).toBe(false);
  expect(after).not.toBe(before);
});
test('deleting by identity leaves other tasks intact', () => {
  const state: Task[] = [{ id: 'a', title: 'React', done: false }, { id: 'b', title: 'Types', done: true }];
  const after = tasksReducer(state, { type: 'deleted', id: 'a' });
  expect(after).toEqual([state[1]]); expect(state).toHaveLength(2);
});
test('storage parser handles missing and corrupted data and deduplicates identities', () => {
  expect(parseTasks(null)).toEqual([]); expect(parseTasks('{broken')).toEqual([]);
  expect(parseTasks('{"tasks":[]}')).toEqual([]);
  const task = { id: 'a', title: 'React', done: false };
  expect(parseTasks(JSON.stringify([task, task, null, { title: 'bad' }]))).toEqual([task]);
});
