import { useTasks } from './TasksContext';
export default function Reports() {
  const { tasks } = useTasks();
  const done = tasks.filter(t => t.done).length;
  return <section className="panel"><h1>تقرير المذاكرة</h1>
    <p>مكتمل: {done}</p><p>متبقي: {tasks.length - done}</p><p>الإجمالي: {tasks.length}</p>
    <p>الأعداد مشتقة من نفس قائمة المهام؛ مفيش state ثانية للعداد.</p>
  </section>;
}
