export type Task = { id: string; title: string; done: boolean };
export type Action =
  | { type: 'added'; task: Task }
  | { type: 'toggled'; id: string }
  | { type: 'deleted'; id: string };
