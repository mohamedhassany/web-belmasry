import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { TasksProvider } from './TasksContext';
import ErrorBoundary from './ErrorBoundary';
import App from './App';
import './style.css';
const queryClient = new QueryClient();
createRoot(document.getElementById('root')!).render(
  <StrictMode><BrowserRouter><QueryClientProvider client={queryClient}>
    <ErrorBoundary><TasksProvider><App /></TasksProvider></ErrorBoundary>
  </QueryClientProvider></BrowserRouter></StrictMode>
);
