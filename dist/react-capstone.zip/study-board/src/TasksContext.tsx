import { createContext, useContext, useEffect, useReducer, useState } from 'react';
import type { Dispatch, ReactNode } from 'react';
import type { Action, Task } from './types';
import { readTasks, storageKey, tasksReducer } from './tasks';

type Value = { tasks: Task[]; dispatch: Dispatch<Action>; saveError: string };
const TasksContext = createContext<Value | null>(null);
export function TasksProvider({ children }: { children: ReactNode }) {
  const [tasks, dispatch] = useReducer(tasksReducer, undefined, readTasks);
  const [saveError, setSaveError] = useState('');
  useEffect(() => {
    try {
      localStorage.setItem(storageKey, JSON.stringify(tasks));
      setSaveError('');
    } catch { setSaveError('التخزين غير متاح. المهام في الجلسة الحالية بس.'); }
  }, [tasks]);
  return <TasksContext.Provider value={{ tasks, dispatch, saveError }}>{children}</TasksContext.Provider>;
}
export function useTasks() {
  const value = useContext(TasksContext);
  if (value === null) throw new Error('TasksProvider missing');
  return value;
}
