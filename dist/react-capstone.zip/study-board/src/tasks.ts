import type { Action, Task } from './types';
export const storageKey = 'frontend-step-capstone-tasks-v1';

export function validateTitle(value: string): string {
  const length = value.trim().length;
  if (length < 3) return 'اكتب ٣ حروف على الأقل.';
  if (length > 80) return 'الحد الأقصى ٨٠ حرفًا.';
  return '';
}
function isTask(value: unknown): value is Task {
  if (typeof value !== 'object' || value === null) return false;
  return 'id' in value && typeof value.id === 'string' && value.id.length > 0
    && 'title' in value && typeof value.title === 'string' && !validateTitle(value.title)
    && 'done' in value && typeof value.done === 'boolean';
}
export function parseTasks(raw: string | null): Task[] {
  try {
    const data: unknown = JSON.parse(raw ?? '[]');
    if (!Array.isArray(data)) return [];
    const ids = new Set<string>();
    return data.filter(isTask).filter(task => {
      if (ids.has(task.id)) return false;
      ids.add(task.id);
      return true;
    }).map(task => ({ id: task.id, title: task.title.trim(), done: task.done }));
  } catch { return []; }
}
export function readTasks(): Task[] {
  try { return parseTasks(localStorage.getItem(storageKey)); }
  catch { return []; }
}
export function tasksReducer(state: Task[], action: Action): Task[] {
  switch (action.type) {
    case 'added':
      if (!isTask(action.task) || state.some(t => t.id === action.task.id)) return state;
      return [...state, { ...action.task, title: action.task.title.trim() }];
    case 'toggled': return state.map(t => t.id === action.id ? { ...t, done: !t.done } : t);
    case 'deleted': return state.filter(t => t.id !== action.id);
    default: { const invalid: never = action; throw new Error('Unknown action: ' + String(invalid)); }
  }
}
