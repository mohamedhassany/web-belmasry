import { lazy, Suspense, useState } from 'react';
import type { FormEvent } from 'react';
import { Link, NavLink, Outlet, Route, Routes, useParams, useSearchParams } from 'react-router';
import { useQuery } from '@tanstack/react-query';
import { useTasks } from './TasksContext';
import { validateTitle } from './tasks';
const Reports = lazy(() => import('./Reports'));

function Layout() {
  const { saveError } = useTasks();
  return <><header className="site-header"><Link className="brand" to="/">Study Board</Link>
    <nav aria-label="التنقل"><NavLink to="/tasks">المهام</NavLink>
      <NavLink to="/reports">التقرير</NavLink><NavLink to="/users">بيانات API</NavLink></nav>
  </header><main className="container">
    {saveError && <p role="alert" className="error">{saveError}</p>}
    <Suspense fallback={<p role="status">بنحمّل كود الشاشة...</p>}><Outlet /></Suspense>
  </main><footer className="container"><p>المهام محفوظة في المتصفح ده بس. مفيش حساب أو مزامنة.</p>
    <a href="https://my-portfolio-gamma-two-39.vercel.app/" target="_blank" rel="noopener noreferrer">Mohamed Hassany ↗</a>
  </footer></>;
}
function Home() {
  return <section className="panel"><p className="eyebrow">مشروع تخرج Frontend Step</p>
    <h1>اتعلّم، طبّق، وراجع.</h1><p>نظم مذاكرتك وتابع المهام. صفحة API منفصلة وتحتاج إنترنت.</p>
    <Link className="button" to="/tasks">ابدأ بالمهام</Link></section>;
}
function TaskForm() {
  const { dispatch } = useTasks();
  const [title, setTitle] = useState('');
  const [error, setError] = useState('');
  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const message = validateTitle(title);
    if (message) { setError(message); return; }
    dispatch({ type: 'added', task: { id: crypto.randomUUID(), title: title.trim(), done: false } });
    setTitle(''); setError('');
  }
  return <form onSubmit={submit} noValidate>
    <label htmlFor="task-title">عنوان المهمة</label>
    <div className="form-row"><input id="task-title" value={title} maxLength={80}
      onChange={e => setTitle(e.target.value)} aria-invalid={Boolean(error)} aria-describedby="task-error" />
      <button type="submit">إضافة مهمة</button></div>
    <p id="task-error" className="error" role="alert">{error}</p>
  </form>;
}
function TasksPage() {
  const { tasks, dispatch } = useTasks();
  const [params, setParams] = useSearchParams();
  const query = params.get('q') ?? '';
  const visible = tasks.filter(t => t.title.toLowerCase().includes(query.trim().toLowerCase()));
  const done = tasks.filter(t => t.done).length;
  return <section className="panel"><h1>خطة المذاكرة</h1><TaskForm />
    <label htmlFor="task-search">بحث في المهام</label>
    <input id="task-search" value={query} onChange={e => {
      const next = new URLSearchParams(params);
      e.target.value ? next.set('q', e.target.value) : next.delete('q');
      setParams(next, { replace: true });
    }} />
    <p className="summary" role="status">خلصت {done} من {tasks.length} مهام</p>
    {visible.length === 0 ? <p>مفيش مهام مطابقة دلوقتي.</p> : <ul className="task-list">
      {visible.map(task => <li key={task.id}>
        <label><input type="checkbox" checked={task.done} onChange={() => dispatch({ type: 'toggled', id: task.id })} />
          <span className={task.done ? 'done' : ''}>{task.title}</span></label>
        <div className="row-actions"><Link to={'/tasks/' + encodeURIComponent(task.id)}>تفاصيل</Link>
          <button className="delete" aria-label={'حذف ' + task.title}
            onClick={() => dispatch({ type: 'deleted', id: task.id })}>حذف</button></div>
      </li>)}
    </ul>}
  </section>;
}
function TaskPage() {
  const { taskId } = useParams();
  const { tasks, dispatch } = useTasks();
  const task = tasks.find(t => t.id === taskId);
  if (!task) return <section className="panel"><h1>المهمة مش موجودة</h1><Link to="/tasks">ارجع للمهام</Link></section>;
  return <section className="panel"><h1>{task.title}</h1><p>{task.done ? 'مكتملة' : 'لسه متبقية'}</p>
    <button onClick={() => dispatch({ type: 'toggled', id: task.id })}>تغيير حالة المهمة</button>{' '}
    <Link to="/tasks">ارجع للمهام</Link></section>;
}
type User = { id: number; name: string };
async function loadUsers({ signal }: { signal: AbortSignal }): Promise<User[]> {
  const response = await fetch('https://jsonplaceholder.typicode.com/users', { signal });
  if (!response.ok) throw new Error('تعذر تحميل البيانات');
  const data: unknown = await response.json();
  if (!Array.isArray(data) || !data.every(u => typeof u === 'object' && u !== null
    && typeof u.id === 'number' && typeof u.name === 'string')) throw new Error('شكل بيانات غير صحيح');
  return data.map(u => ({ id: u.id, name: u.name }));
}
function UsersPage() {
  const query = useQuery({ queryKey: ['demo-users'], queryFn: loadUsers, staleTime: 60_000, retry: 1 });
  if (query.isPending) return <p role="status">بنحمّل بيانات المستخدمين...</p>;
  if (query.isError) return <section className="panel" role="alert"><h1>التحميل ماكملش</h1>
    <p>الخدمة تجريبية وتحتاج إنترنت. المهام المحلية لسه مستقلة عنها.</p>
    <button onClick={() => query.refetch()}>إعادة محاولة</button></section>;
  return <section className="panel"><h1>بيانات تجريبية من API</h1>
    <p>دي أسماء عامة من JSONPlaceholder، مش حسابات التطبيق.</p>
    {query.isFetching && <p role="status">بنحدّث النسخة...</p>}
    {query.data.length ? <ul>{query.data.map(u => <li key={u.id}>{u.name}</li>)}</ul> : <p>مفيش بيانات.</p>}
  </section>;
}
export default function App() {
  return <Routes><Route element={<Layout />}>
    <Route index element={<Home />} />
    <Route path="tasks" element={<TasksPage />} />
    <Route path="tasks/:taskId" element={<TaskPage />} />
    <Route path="reports" element={<Reports />} />
    <Route path="users" element={<UsersPage />} />
    <Route path="*" element={<section className="panel"><h1>الصفحة مش موجودة</h1><Link to="/">الرئيسية</Link></section>} />
  </Route></Routes>;
}
