import { Component } from 'react';
import type { ReactNode, ErrorInfo } from 'react';
export default class ErrorBoundary extends Component<{ children: ReactNode }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() { return { failed: true }; }
  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error('Render failure:', error.message, info.componentStack);
  }
  render() {
    if (this.state.failed) return <main className="panel" role="alert">
      <h1>حصل خطأ في عرض الجزء ده.</h1><p>تقدر تعيد تحميل الصفحة وتجرب تاني.</p>
      <button onClick={() => window.location.reload()}>إعادة تحميل</button>
    </main>;
    return this.props.children;
  }
}
