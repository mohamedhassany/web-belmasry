# Study Board — مشروع تخرج Frontend Step

مشروع React متكامل للتطبيق على مسار الشرح، إعداد Mohamed Hassany.

## التشغيل

Node.js LTS حديثة ومدعومة، الإصدار الأدنى في هذا المشروع 22.12. نفّذ من نفس المجلد الذي يحتوي package.json:

```text
npm install
npm run dev
npm run test:run
npm run build
npm run preview
```

الأوامر تخص مشروع التخرج فقط؛ الموقع التعليمي Frontend Step نفسه static ولا يحتاج هذه الحزم.

## المميزات وحدودها

- React 19 مع TypeScript وReact Router 7 وTanStack Query 5.
- إضافة مهام والتحقق من طولها، إكمالها وحذفها، بحث في URL وصفحة لكل مهمة.
- Reducer وContext، وحفظ محلي مع معالجة التخزين التالف أو غير المتاح.
- صفحة تقرير محملة بـlazy وSuspense، وError Boundary.
- صفحة بيانات تجريبية من JSONPlaceholder؛ تحتاج إنترنت، وتغطي انتظارًا وخطأ وإعادة محاولة.
- اختبارات قواعد بيانات وتفاعل وغياب مورد باستخدام Vitest وTesting Library.
- تصميم عربي متجاوب وحقول مسماة وتركيز مرئي.

المهام في localStorage لهذا المتصفح والأصل فقط. لا حسابات ولا خادم مهام ولا مزامنة بين الأجهزة. API العامة ليست مخزن المهام.

لا أسرار خدمة في كود العميل أو VITE_*. حماية حسابات وكتابات حقيقية تحتاج Backend والتحقق والتفويض عنده.

## قراءة المصدر

ابدأ types.ts ثم tasks.ts ثم TasksContext.tsx ثم main.tsx وApp.tsx. Reports.tsx ملف منفصل لتحميل lazy. الاختبارات في tasks.test.ts وApp.test.tsx.

## النشر

ارفع هذا المشروع لمستودع مستقل إن أردت نشره. في Vercel اختار Vite، وأمر البناء npm run build والمخرج dist. ملف vercel.json يدعم فتح روابط SPA عميقة. اختبر /tasks وأي رابط تفاصيل مباشرة بعد النشر.

ملف package-lock.json الناتج مع التثبيت يثبّت اختيارات نسخ الحزم؛ احتفظ به مع مشروعك. لا ترفع node_modules أو أسرارًا.

## تمارين تطوير

1. تعديل عنوان المهمة مع Action جديدة وفحص طول واختبار.
2. حالة filter=all/done/open في URL مع الحفاظ على q.
3. حوار تأكيد حذف قابل للكيبورد والإغلاق والتركيز.
4. عند الحاجة لخادم: صمّم API وصلاحيات ومفاتيح بيانات لكل مستخدم قبل التوصيل.

البورتفوليو: https://my-portfolio-gamma-two-39.vercel.app/
